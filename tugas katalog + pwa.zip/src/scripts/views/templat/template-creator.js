import CONFIG from "../../globals/config";

const panoHome = (pano) => `
  <div tabindex="0" class="restaurant-list" id="restaurant-list">
    <div class="restaurant-item">
        <h2>${pano.name}</h2>
        <img src="${CONFIG.imageMedium + pano.pictureId}" alt="gambar-pano ${pano.pictureId}">
        <p>City : ${pano.city}</p>
        <p>Ratting : ${pano.rating}⭐️</p>
        <p>${pano.description}</p>
    </div>
  </div>
`;

export { panoHome };