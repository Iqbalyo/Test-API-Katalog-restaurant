const Favorite = {
    async render() {
      return `
        <h2>Upcoming page</h2>
      `;
    },
   
    async afterRender() {
      // Fungsi ini akan dipanggil setelah render()
    },
  };
   
  export default Favorite;