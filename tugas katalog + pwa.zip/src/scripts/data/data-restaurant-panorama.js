import ENDPOINT_OF_API from "../globals/endpoint";

class Panorama {
    static async restoHomePage() {
        const response = await fetch(ENDPOINT_OF_API.MAIN);
        const responseJson = await response.json();
        return responseJson.restaurants;
    }


    //restoDetailPage(), halamannya beda. Bukan di home.js
    static async restoDetailPage(id) {
        const response = await fetch(ENDPOINT_OF_API.DETAIL_PAGE(id));
        const responseJson = await response.json();
        return responseJson.restaurant;
        
    }
}

export default Panorama;

//ubah be penamaannya. Nama filenya jangan resfavorite.
//karna ini bukan untuk favorite, tapi untuk main sama detail
