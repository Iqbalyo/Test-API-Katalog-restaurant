import CONFIG from "./config";

const ENDPOINT_OF_API = {
    MAIN: `${CONFIG.Baseurl}/list`, // list klo dk salah sudah ketentuan dari doc API ny
    DETAIL: (id) => `${CONFIG.Baseurl}/detail/${id}`  ///detail/${id} ini juga klo dk salah sudah ketentuan dari doc API ny
};

export default ENDPOINT_OF_API;



