const CONFIG = {
    Baseurl : 'https://restaurant-api.dicoding.dev',
    imageSmall : 'https://restaurant-api.dicoding.dev/images/small/<pictureId>',
    imageMedium : 'https://restaurant-api.dicoding.dev/images/medium/',
    imageLarge : 'https://restaurant-api.dicoding.dev/images/large/',

};

export default CONFIG;