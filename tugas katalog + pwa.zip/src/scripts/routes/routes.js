
import Home from '../views/pages/home';
import Favorite from '../views/pages/favorite';
import About from '../views/pages/aboutus';
 
const routes = {
  '/': Home, // default page
  '/home': Home,
  '/favorite': Favorite,
  '/aboutus/:id': About,
};
 
export default routes;