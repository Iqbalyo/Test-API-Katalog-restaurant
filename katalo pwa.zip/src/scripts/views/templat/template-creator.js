import CONFIG from "../../globals/config";

const panoHome = (pano) => `

<div class="restaurant-item">
<a href="/#/detailRestorant/${pano.id}"><h2>${pano.name}</h2></a>
  <img src="${CONFIG.imageMedium + pano.pictureId}" alt="gambar-pano ${pano.pictureId}">
  <p>City : ${pano.city}</p>
    <p>Ratting : ${pano.rating}⭐️</p>
    <p>${pano.description}</p><p></p>
</div>

`;

const detailPano = (panos) => `
  <h1>Restaurant Details</h1>
  <h2>${panos.name}</h2>
  <img src="${CONFIG.imageMedium + panos.pictureId}" alt="gambar-pano ${panos.pictureId}">
  <p>City : ${panos.city}</p>
  <p>Ratting : ${panos.rating}⭐️</p>
  <p>${panos.description}</p>
`;



export { panoHome, detailPano };
