import UrlParser from "../../routes/url-parser";
import Panorama from "../../data/data-restaurant-panorama";
import { detailPano } from "../templat/template-creator";



const detailRestorant = {
 async render() {
  return `
   <div id="detail" class="detail">
    <h2>Browse Restaurants</h2>
   </div>
  `;
 },

 async afterRender() {
   const url = UrlParser.parseActiveUrlWithoutCombiner(); 
   const panos = await Panorama.restoDetailPage(url.id); 
   const savcontainer = document.querySelector('#detail');
   savcontainer.innerHTML = detailPano(panos);
   console.log('Hello World');
  },
 };
  
 export default detailRestorant;