const urlAPI = "https://restaurant-api.dicoding.dev/list";

fetch(urlAPI)
  .then((response) => response.json())
  .then((data) => {
    const restoranList = document.getElementById("restoran-list");

    data.restaurants.forEach((restoran) => {
      const listItem = document.createElement("li");
      listItem.className = "restoran-item";

      const namaRestoran = document.createElement("h3");
      namaRestoran.textContent = restoran.name;
      listItem.appendChild(namaRestoran);

      const gambarRestoran = document.createElement("img");
      gambarRestoran.src = restoran.picture;
      gambarRestoran.alt = "Gambar Restoran " + restoran.name;
      listItem.appendChild(gambarRestoran);

      const infoRestoran = document.createElement("p");

      if (restoran.city) {
        infoRestoran.textContent = "Kota: " + restoran.city;
      } else if (restoran.rating) {
        infoRestoran.textContent = "Rating: " + restoran.rating;
      } else {
        infoRestoran.textContent = "Deskripsi: " + restoran.description;
      }

      listItem.appendChild(infoRestoran);

      restoranList.appendChild(listItem);
    });
  })
  .catch((error) => {
    console.error("Error:", error);
  });
