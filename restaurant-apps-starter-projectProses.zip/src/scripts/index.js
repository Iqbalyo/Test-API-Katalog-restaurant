import '../styles/main.css';
import 'regenerator-runtime'; 
import App from './views/app';

const drawerButton = document.querySelector('.drawer');
const navBar = document.querySelector('.nav-bar');

drawerButton.addEventListener('click', () => {
  navBar.classList.toggle('active');
});

// 




