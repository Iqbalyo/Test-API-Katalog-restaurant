import Home from '../views/pages/home';
import Favorite from '../views/pages/favorite';
import About from '../views/pages/aboutus';
import { toggleNavBar } from '..';
import detailRestorant from '../views/pages/detailrestorant';


toggleNavBar(); 
const routes = {
 '/': Home, // default page
 '/home': Home,
 '/favorite': Favorite,
 '/aboutus/:id': About,
 '/detailrestorant/:id': detailRestorant,

};
 
export default routes;
