import '../styles/main.css';
import 'regenerator-runtime';
import App from './views/app';

const mainBody = document.querySelector('#maincontent');
const app = new App({
  button: document.querySelector('#hamburger'),
  drawer: document.querySelector('#drawer'),
  content: document.querySelector('#maincontent'),
});

window.addEventListener('hashchange', () => {
  app.renderPage();
});

window.addEventListener('load', () => {
  app.renderPage();
});

export function toggleNavBar() {
  const drawerButton = document.querySelector('.drawer');
  const navBar = document.querySelector('.nav-bar');

  drawerButton.addEventListener('click', () => {
    navBar.classList.toggle('active');
  });
}

// console.log('hello world');




